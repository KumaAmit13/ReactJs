const {Router}=require("express")
const {registerUser,logoutUser,login, refreshAccessToken,updatePassword ,getcurrentUser ,updateAccountDetails,updateAvtarImage,updateCoverImage, getUserChannelProfile, watchHistory} = require("../controllers/user.controller.js")
const upload = require("../middlewares/multer.middleware.js")
const verifyJWT = require("../middlewares/auth.middleware.js")


const router=Router()

router.route("/register").post(upload.fields([{name:"avatar",maxCount:1},{name:"coverImage",maxCount:1}]),registerUser)
router.route("/login").post(login)

// updatePAssword ,getcurrentUser ,updateAccountDetails,updateAvtarImage,updateCoverImage

router.route("/logout").post(verifyJWT,logoutUser);
router.route("/refresh-token").post(refreshAccessToken);
router.route("/getcurrentuser").post(verifyJWT,getcurrentUser);
router.route("/update/Password").patch(verifyJWT,updatePassword);
router.route("/update/accountDetails").patch(verifyJWT,updateAccountDetails);
router.route("/update/avatar").patch(verifyJWT,upload.single("avatar"),updateAvtarImage);
router.route("/update/coverimage").patch(verifyJWT,upload.single("coverImage"),updateCoverImage);
router.route("/c/:userName").get(verifyJWT,getUserChannelProfile)
router.route("/history").get(verifyJWT,watchHistory);
// router.route("/update/Password").post(verifyJWT,updatePassword);
module.exports=router
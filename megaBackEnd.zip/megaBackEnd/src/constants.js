const DB_NAME="BackendWithNodeJs"
module.exports = DB_NAME;

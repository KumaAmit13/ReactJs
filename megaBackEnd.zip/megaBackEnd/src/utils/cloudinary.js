const {v2: cloudinary}=require('cloudinary');
require("dotenv").config()

const fs=require("fs");
const ApiError = require('./ApiErrors');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true // ensures HTTPS URLs
});


const uploadOnCloudinary = async (localFilePath) => {
    try {
        // console.log("env details", process.env.CLOUDINARY_CLOUD_NAME,process.env.CLOUDINARY_API_KEY, process.env.CLOUDINARY_API_SECRET)
        if(!localFilePath){
            console.log("cloud't find the file path")
            return null;
        }
        console.log("i am ruuning in clodinery try block")

        //upload on cloudinary
        const response=await cloudinary.uploader.upload(localFilePath,{
            resource_type:'auto',
            folder: "uploads" 
        })
        fs.unlinkSync(localFilePath)
        console.log("file uploaded on cloudinary",response);
        return response;
    } catch (error) {
        fs.unlinkSync(localFilePath);
        console.log("file upload filed on clodinary",error)
        return new ApiError(500,"file upload filed on clodinary");
    }
}

const deleteOnCloudinary=async(public_Id)=>{
    try {
        const result=await cloudinary.uploader.destroy(public_Id,{resource_type:'image'})
        console.log("deleteOnCloudinary",result)
        return result;
    } catch (error) {
        console.log("faild to delete the resorce");
        throw new ApiError(500,error.message || "falid to delete" );
    }
}

module.exports={uploadOnCloudinary,deleteOnCloudinary};
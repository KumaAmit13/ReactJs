const mongoose = require("mongoose")


const palyListSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true
        },
        discription: {
            type: String,
            required: true
        },

        videos: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: "Video"
            }
        ]
        ,
        owner: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User"
        },
    },
    { timestamps: true }
)




const PlayList = mongoose.model("PlayList", palyListSchema);
module.exports = PlayList
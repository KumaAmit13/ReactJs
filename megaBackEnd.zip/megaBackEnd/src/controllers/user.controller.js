const jwt = require("jsonwebtoken");
const upload = require("../middlewares/multer.middleware.js");
const User = require("../models/user.model.js");
const ApiError = require("../utils/ApiErrors.js");
const ApiResponse = require("../utils/ApiResponse.js");
const asyncHandler = require("../utils/asyncHandler.js");
const {uploadOnCloudinary,deleteOnCloudinary} = require("../utils/cloudinary.js");
const { default: mongoose } = require("mongoose");

// require(".")
const generateAccessAndRefereshTokens = async (userID) => {
    try {
        const user = await User.findById(userID);
        console.log("user_id", userID)
        const accessToken = user.generateAccessToken();
        const refreshToken = user.generateRefreshToken();
        console.log(" and and ", refreshToken);

        user.refreshToken = refreshToken;
        await user.save({ validateBeforeSave: false });

        return { accessToken, refreshToken }
    } catch (error) {
        throw new ApiError(500, "Something went wrong while generating referesh and access token")

    }
}





const registerUser = asyncHandler(async (req, res) => {
    const { fullName, email, userName, password } = req.body;

    if (
        [fullName, email, userName, password].some((element) => element?.trim() === "")
    ) {
        throw new ApiError(400, "All fileds are required")

    }

    const duplicateUser = await User.findOne({ $or: [{ userName }, { email }] });

    if (duplicateUser) {
        throw new ApiError(401, "user alReady registered..")
    }
    // console.log("files",req.files)
    const avatarLocalPath = await req.files?.avatar[0]?.path;
    let coverImageLocalPath = "";
    if (req.files && Array.isArray(req.files.coverImage) && req.files.coverImage.length > 0) {
        coverImageLocalPath = req.files.coverImage[0].path;

    }
    console.log("local path: ", avatarLocalPath)
    if (!avatarLocalPath) {
        throw new ApiError(400, "one avatar file is required");
    }

    const avatar = await uploadOnCloudinary(avatarLocalPath);
    console.log("hii i am avatra", avatar + 1)
    const coverImage = await uploadOnCloudinary(coverImageLocalPath);
    if (!avatar) {
        throw new ApiError(400, "acatar file is required cloudinary");
    }

    const user = await User.create({
        fullName,
        avatar: {url: avatar?.url, public_Id: avatar.public_id},
        coverImage:{url: coverImage?.url || "",public_Id: coverImage?.public_id || ""},
        email,
        password,
        userName: userName.toLowerCase()
    })

    //fliter two filed from user

    const createUser = await User.findById(user._id).select(
        "-password -refreshToken"
    )
    console.log("i am user", createUser)

    return res.status(201).json(
        new ApiResponse(200, { createUser }, "User registered....")
    )

})


const login = asyncHandler(async (req, res) => {
    console.log(req.body);
    const { userName, email, password } = req.body;
    if (!(userName || email)) {
        console.log("username/email and password can't be empty")
        throw new ApiError(400, "username/email and password can't be empty");
    }
    const user = await User.findOne({ $or: [{ userName }, { email }] });
    if (!user) {
        console.log("enter details are incorect please check your deatils angain and tried")
        throw new ApiError(400, "enter details are incorect please check your deatils angain and tried")
    }

    const isPasswordCorrect = user.isPasswordCorrect(password);
    if (!isPasswordCorrect) {
        console.log("enter password are incorect please check your password angain and tried")
        throw new ApiError(400, "enter password are incorect please check your password angain and tried")
    }
    const { accessToken, refreshToken } = await generateAccessAndRefereshTokens(user._id);

    const loggedInUser = await User.findById(user._id).select("-password -refreshToken");

    const options = { httpOnly: true, secure: true }//now only server modified these cookies

    return res.status(200).cookie("accessToken", accessToken, options).
        cookie("refreshToken", refreshToken, options).json(
            new ApiResponse(200, { user: loggedInUser, accessToken, refreshToken }, "user loged in successfully")
        );

})


const logoutUser = asyncHandler(async (req, res) => {
    User.findByIdAndUpdate(req.user?._id, { $unset: { refreshToken: 1 } }
        , {
            new: true
        }
    )

    const options = { httpOnly: true, secure: true }//now only server modified these cookies
    return res.status(200)
        .clearCookie("accessToken", options)
        .clearCookie("refreshToken", options)
        .json(new ApiResponse(200, {}, "userLogOut seccessfully"));
})

const refreshAccessToken = asyncHandler(async (req, res) => {
    const incomingRefreshToken = req.cookies.refreshToken || req.body.refreshToken
    console.log(incomingRefreshToken)
    if (!incomingRefreshToken) {
        throw new ApiError(401, "unauthorized request")
    }
    try {
        const decodedToken = jwt.verify(incomingRefreshToken, process.env.REFRESH_TOKEN_SECRET);
        const user = await User.findById(decodedToken._id);

        if (!user) {
            throw new ApiError(401, "Invalid Refresh token");
        }

        if (incomingRefreshToken !== user?.refreshToken) {
            throw new ApiError(401, "Refresh token is expired or used")
        }

        const options = {
            httpOnly: true,
            secure: true
        }

        const { accessToken, newRefreshToken } = await generateAccessAndRefereshTokens(user._id);
        console.log("refreshedd", newRefreshToken);

        return res.status(200).cookie("accessToken", accessToken, options)
            .cookie("refreshToken", newRefreshToken, options)
            .json(
                new ApiResponse(200, { accessToken, refreshToken: newRefreshToken }, "Access token refreshed")
            )



    } catch (error) {
        throw new ApiError(401, error?.message || "Invalid refresh token")

    }
})

const updatePassword = asyncHandler(async (req, res) => {
    const { oldPassword, newPassword } = req.body;
    //by using authMiddleware
    const user = await User.findById(req.user?._id);
    const isOldPasswordCorrect = await user.isPasswordCorrect(oldPassword);
    if (!isOldPasswordCorrect) {
        throw new ApiError(400, "oldPassword is in correct");
    }
    user.password = newPassword;
    await user.save({ validateBeforeSave: false });

    return res.status(200)
        .json(new ApiResponse(200, { newPassword }, "user Password changed successfully...."));
})

const getcurrentUser = asyncHandler(async (req, res) => {
    return res.status(200).json(new ApiResponse(200, req.user, "user details facthed successfully"))
});

const updateAccountDetails = asyncHandler(async (req, res) => {
    const { fullName, email } = req.body;

    if (!fullName || !email) {
        throw new ApiError(400, "fullname or email can't be empty");
    }

    const user = await User.findByIdAndUpdate(req.user?._id,
        { $set: { fullName: fullName, email: email } },
        { new: true }
    ).select("-password");
    return res.status(200).json(new ApiResponse(200, user, "user Account Details updated seccessfully"))
})


const updateAvtarImage = asyncHandler(async (req, res) => {
    const avatarLocalPath = req.file?.path;
    if (!avatarLocalPath) {
        throw new ApiError(400, "upload a valid image for avatar")
    }
    const avatar = await uploadOnCloudinary(avatarLocalPath);

    if (!avatar.url) {
        throw new ApiError(500, "getting error on upload avatar on cloudinary")
    }

    const {url,public_Id}=req.user?.avatar;
    await deleteOnCloudinary(public_Id);
    const user = await User.findByIdAndUpdate(req.user._id,
        {
            $set: {
                avatar:{url: avatar.url,public_Id:avatar.public_id}
            }
        },
        { new: true }
    ).select("-password");


    return res.status(200).json(new ApiResponse(200, user, "user avatar image update seccessfully"))
})

const updateCoverImage = asyncHandler(async (req, res) => {
    const coverImageLocalPath = req.file?.path;
    if (!coverImageLocalPath) {
        throw new ApiError(400, "upload a valid image for avatar")
    }
    const coverImage = await uploadOnCloudinary(coverImageLocalPath);

    if (!coverImage.url) {
        throw new ApiError(500, "getting error on upload cover image on cloudinary")
    }

    const user = await User.findByIdAndUpdate(req.user._id,
        {
            $set: {
                coverImage: coverImage.url
            }
        },
        { new: true }
    ).select("-password");

    return res.status(200).json(new ApiResponse(200, user, "user cover image update seccessfully"))
})

const getUserChannelProfile = asyncHandler(async (req, res) => {
    const { userName } = req.params;//end ponit www./../:userName

    if (!userName?.trim()) {
        throw new ApiError(400, "userName is missing");
    }

    const channel = await User.aggregate([
        {
            $match: {
                userName: userName?.toLowerCase()
            }
        },
        {
            $lookup: {
                from: "subscriptions",
                localField: "_id",
                foreignField: "channel",
                as: "subscribers"
            }
        },
        {
            $lookup: {
                from: "subscriptions",
                localField: "_id",
                foreignField: "subscriber",
                as: "subscribedTo"
            }
        },
        {
            $addFields: {
                subscribersCount: {
                    $size: "$subscribers"
                },
                channelsSubscribedToCount: {
                    $size: "$subscribedTo"
                },
                isSubscribed: {
                    $cond: {
                        if: { $in: [req.user?._id, "$subscribers.subscriber"] },
                        then: true,
                        else: false
                    }
                }
            }
        },
        {
            $project:{
                fullName:1,
                userName:1,
                subscribersCount:1,
                channelsSubscribedToCount:1,
                isSubscribed:1,
                avatar:1,
                coverImage:1,
                email:1
            }
        }
    ]);

    if(!channel?.length){
        throw new ApiError(404,"channel does not exists")
    }

    return res.status(200).json(new ApiResponse(200,channel[0],"user channel fectched successfully"))
})

const watchHistory=asyncHandler(async(req,res)=>{
     const user = await User.aggregate([
        {
            $match: {
                _id: new mongoose.Types.ObjectId(req.user._id)
            }
        },
        {
            $lookup: {
                from: "videos",
                localField: "watchHistory",
                foreignField: "_id",
                as: "watchHistory",
                pipeline: [
                    {
                        $lookup: {
                            from: "users",
                            localField: "owner",
                            foreignField: "_id",
                            as: "owner",
                            pipeline: [
                                {
                                    $project: {
                                        fullName: 1,
                                        username: 1,
                                        avatar: 1
                                    }
                                }
                            ]
                        }
                    },
                    {
                        $addFields:{
                            owner:{
                                $first: "$owner"
                            }
                        }
                    }
                ]
            }
        }
    ])

    return res
    .status(200)
    .json(
        new ApiResponse(
            200,
            user[0].watchHistory,
            "Watch history fetched successfully"
        )
    )
})





module.exports = {
    registerUser, login, logoutUser, refreshAccessToken,
    updatePassword, getcurrentUser, updateAccountDetails,
     updateAvtarImage, updateCoverImage,getUserChannelProfile,
     watchHistory
}
